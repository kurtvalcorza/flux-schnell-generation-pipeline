"""Probes for the Notebook Review Framework v1 review of tutorials/flux_schnell_generation_colab.ipynb (row 27).

CPU-only; no FLUX weights are downloaded or loaded. Probes P3/P4 execute the notebook's own carried module cells
(5, 7, 9) and its Section 4 cell (13) in one namespace with a google.colab shim; P5/P7 use the archived Kaggle T4
run of the same notebook blob (documented execution evidence). Usage:
    python run_probes.py <worktree> <kaggle_evidence_dir>
Writes results.json and source_manifest.json next to this script.
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import math
import os
import subprocess
import sys
import tempfile
import time
import types
import zipfile
from pathlib import Path

WT = Path(sys.argv[1])
EV = Path(sys.argv[2])
HERE = Path(__file__).resolve().parent
NB_PATH = WT / "tutorials" / "flux_schnell_generation_colab.ipynb"
results: dict = {"probes": {}}
t_start = time.time()


def record(name, value):
    results["probes"][name] = value
    print(name, json.dumps(value, default=str)[:600])


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]

# ---------------- P1 static structure
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
compile_errors = {}
for i in code_idx:
    try:
        compile(src[i], f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors[i] = str(exc)
md_all = "\n".join(src[i] for i, c in enumerate(cells) if c["cell_type"] == "markdown")
markers = {k: md_all.lower().count(k.lower()) for k in [
    "How to use", "Infrastructure", "Predict", "Glossary", "Troubleshoot", "Expected result", "What to notice",
    "Look for", "Checkpoint", "Sample answer", "<details", "Roadmap", "Input →", "learner", "audience",
    "pretraining", "overlap", "restart"]}
carried_lines = sum(len(src[i].splitlines()) for i in (5, 7, 9))
blob = subprocess.run(["git", "-C", str(WT), "rev-parse", "HEAD:tutorials/flux_schnell_generation_colab.ipynb"],
                      capture_output=True, text=True).stdout.strip()
record("P1_static", {
    "nbformat": nb.get("nbformat"), "cells": len(cells), "code_cells": len(code_idx), "compile_errors": compile_errors,
    "metadata_dimer": {k: v for k, v in nb["metadata"].get("dimer", {}).items() if k != "generated_from"},
    "generated_from_revision": nb["metadata"]["dimer"]["generated_from"]["revision"],
    "outputs_persisted": any(c.get("outputs") for c in cells if c["cell_type"] == "code"),
    "carried_module_lines": carried_lines,
    "carried_cells_collapsed": {i: cells[i].get("metadata", {}).get("cellView") or cells[i].get("metadata", {}).get("jupyter") for i in (5, 7, 9)},
    "guided_markers_in_markdown": markers,
    "notebook_blob": blob, "recorded_kaggle_blob": "522268125c9147c498e6ad873d22eeb33f42d8b5",
    "blob_matches_recorded_run": blob == "522268125c9147c498e6ad873d22eeb33f42d8b5",
    "env_vars_read": sorted({w for w in ["DIMER_NOTEBOOK_CI_PREINSTALLED"] if w in "".join(src[i] for i in code_idx if i not in (5, 7, 9))}),
    "env_var_documented_in_markdown": "DIMER_NOTEBOOK_CI_PREINSTALLED" in md_all,
})

# ---------------- P2 provenance: carried module text vs repository revisions
def git_show(rev, path):
    return subprocess.run(["git", "-C", str(WT), "show", f"{rev}:{path}"], capture_output=True).stdout


prov = {}
for i in (5, 7, 9):
    rel = cells[i]["metadata"]["dimer"]["embedded_module"]
    cell_sha = hashlib.sha256(src[i].encode()).hexdigest()
    prov[rel] = {
        "cell_metadata_sha256": cells[i]["metadata"]["dimer"]["module_sha256"],
        "src_HEAD_sha256": hashlib.sha256(git_show("HEAD", rel)).hexdigest(),
        "src_at_recorded_revision_77567b7_sha256": hashlib.sha256(git_show("77567b768674bce3fb402388c1fb7053bbfc8fe0", rel)).hexdigest(),
    }
    prov[rel]["cell_meta_equals_HEAD"] = prov[rel]["cell_metadata_sha256"] == prov[rel]["src_HEAD_sha256"]
    prov[rel]["cell_meta_equals_recorded_revision"] = prov[rel]["cell_metadata_sha256"] == prov[rel]["src_at_recorded_revision_77567b7_sha256"]
ns_src = src[3]
record("P2_provenance", {
    "NOTEBOOK_SOURCE_repository_revision": "77567b768674bce3fb402388c1fb7053bbfc8fe0" if "77567b768674bce3fb402388c1fb7053bbfc8fe0" in ns_src else "?",
    "modules": prov,
    "suffix_rule_differs_between_revisions": b".md" in git_show("HEAD", "src/flux_schnell_generation_pipeline/pipeline.py").split(b"SNAPSHOT_FILE_SUFFIXES")[1][:200]
    and b".md" not in git_show("77567b768674bce3fb402388c1fb7053bbfc8fe0", "src/flux_schnell_generation_pipeline/pipeline.py").split(b"SNAPSHOT_FILE_SUFFIXES")[1][:200],
})

# ---------------- P3 default data stages: carried modules + Section 4 cell, CPU
work = Path(tempfile.mkdtemp(prefix="r27_"))
os.chdir(work)
ns: dict = {"__name__": "__main__"}
t0 = time.time()
for i in (5, 7, 9):
    exec(compile(src[i], f"cell{i}", "exec"), ns)
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    exec(compile(src[13], "cell13", "exec"), ns)
out13 = buf.getvalue().splitlines()
record("P3_default_section4", {
    "seconds": round(time.time() - t0, 1),
    "stdout_head": [l[:300] for l in out13],
    "splits": {k: len(ns[k]) for k in ("train_records", "val_records", "test_records")},
    "observers_per_species_unique": None,
    "csv_written": (work / "outputs/flux_schnell_generation_sample_captions.csv").is_file(),
})
# observer overlap check across splits (SPL5)
obs = {}
for name in ("train_records", "val_records", "test_records"):
    for r in ns[name]:
        obs.setdefault((r["label"], r["observer"]), set()).add(name)
results["probes"]["P3_default_section4"]["species_observer_pairs_in_two_splits"] = sum(1 for v in obs.values() if len(v) > 1)

# ---------------- P4 BYOD via the notebook's own cell 13 with a google.colab shim
from PIL import Image  # noqa: E402
import numpy as np  # noqa: E402


def img_bytes(seed, size=(320, 300), fmt="JPEG"):
    rng = np.random.default_rng(seed)
    arr = rng.integers(0, 255, size=(size[1], size[0], 3), dtype=np.uint8)
    b = io.BytesIO()
    Image.fromarray(arr).save(b, fmt)
    return b.getvalue()


def make_zip(rows, extra=None, header="id,file,caption"):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        lines = [header] + [f"{r[0]},{r[1]},{r[2]}" for r in rows]
        z.writestr("captions.csv", "\n".join(lines) + "\n")
        for r in rows:
            if len(r) > 3 and r[3] is not None:
                z.writestr(r[3] if len(r) > 4 and r[4] else r[1], r[3] if isinstance(r[3], bytes) else b"")
        for name, data in (extra or {}).items():
            z.writestr(name, data)
    return b.getvalue()


def rows_for(captions_counts, start=0):
    rows, k = [], start
    for c, n in captions_counts:
        for _ in range(n):
            rows.append((f"r{k:04d}", f"img{k:04d}.jpg", c))
            k += 1
    return rows


def build_zip(rows, dup_of=None, subdir=False, bad_image_ids=()):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        lines = ["id,file,caption"]
        for j, (rid, fname, cap) in enumerate(rows):
            name = ("images/" + fname) if subdir else fname
            lines.append(f"{rid},{name},{cap}")
            if rid in bad_image_ids:
                data = b"not an image"
            elif dup_of and rid in dup_of:
                data = img_bytes(dup_of[rid])
            else:
                data = img_bytes(1000 + j)
            z.writestr(name, data)
        z.writestr("captions.csv", "\n".join(lines) + "\n")
    return b.getvalue()


def run_byod(zip_bytes, label, cancel=False):
    files_mod = types.SimpleNamespace(upload=(lambda: {}) if cancel else (lambda: {f"{label}.zip": zip_bytes}))
    colab = types.ModuleType("google.colab")
    colab.files = files_mod
    google = types.ModuleType("google")
    google.colab = colab
    sys.modules["google"], sys.modules["google.colab"] = google, colab
    cell = src[13].replace("USE_BYOD = False", "USE_BYOD = True", 1)
    local = dict(ns)
    b = io.StringIO()
    try:
        with contextlib.redirect_stdout(b):
            exec(compile(cell, "cell13_byod", "exec"), local)
        out = {"outcome": "accepted", "splits": {k: len(local[k]) for k in ("train_records", "val_records", "test_records")},
               "n_prompts_for_generation": len(local["prompts"]),
               "n_records_after_split": sum(len(local[k]) for k in ("train_records", "val_records", "test_records"))}
    except BaseException as exc:  # noqa: BLE001
        out = {"outcome": "refused", "type": type(exc).__name__, "message": str(exc)[:200]}
    return out


byod = {}
byod["stated_minimum_4_images_1_caption"] = run_byod(build_zip(rows_for([("a red barn", 4)])), "m4")
byod["5_images_1_caption"] = run_byod(build_zip(rows_for([("a red barn", 5)])), "m5")
byod["6_images_1_caption"] = run_byod(build_zip(rows_for([("a red barn", 6)])), "m6")
byod["4_images_1_caption_plus_3_singletons"] = run_byod(build_zip(rows_for([("a red barn", 4), ("x1", 1), ("x2", 1), ("x3", 1)])), "m4s")
byod["20_images_unique_captions"] = run_byod(build_zip(rows_for([(f"caption {i}", 1) for i in range(20)])), "uniq")
byod["3_captions_x_10_images"] = run_byod(build_zip(rows_for([("cap a", 10), ("cap b", 10), ("cap c", 10)])), "c3")
byod["30_images_25_unique_plus_1x5"] = run_byod(build_zip(rows_for([(f"u{i}", 1) for i in range(25)] + [("shared", 5)])), "mix")
dup_rows = rows_for([("cap a", 10), ("cap b", 10)])
byod["20_images_with_6_pixel_duplicates"] = run_byod(build_zip(dup_rows, dup_of={dup_rows[i][0]: 1000 for i in range(1, 7)}), "dup")
byod["file_in_subfolder_listed_with_path"] = run_byod(build_zip(rows_for([("cap a", 10)]), subdir=True), "sub")
byod["one_non_image_member"] = run_byod(build_zip(rows_for([("cap a", 10)]), bad_image_ids={"r0003"}), "bad")
byod["not_a_zip"] = run_byod(b"plain text", "notzip")
byod["upload_cancelled"] = run_byod(b"", "cancel", cancel=True)
record("P4_byod_cell13", byod)

# ---------------- P5 real-photo 'ceiling' self-inclusion, from the archived Kaggle T4 report of this blob
rep = json.loads((EV / "outputs" / "flux_schnell_generation_evaluation_report.json").read_text(encoding="utf-8"))
rc = rep["real_photo_ceiling"]
per_caption = {}
for e in rc["per_image"]:
    per_caption.setdefault(e["prompt"], []).append(e["reference_similarity"])
loo = {}
for cap, vals in per_caption.items():
    v = vals[0] / 100.0
    # with two test photos a, b of one caption: cos(a, (a+b)/|a+b|) = sqrt((1 + cos(a,b)) / 2)
    loo[cap[13:40]] = {"n": len(vals), "self_inclusive": vals[0], "leave_one_out_cos_x100": round((2 * v * v - 1) * 100, 2)}
loo_mean = round(sum(x["leave_one_out_cos_x100"] for x in loo.values()) / len(loo), 2)
# synthetic check of the identity with random unit vectors (stand-in for CLIP embeddings)
rng = np.random.default_rng(0)
a, b2 = rng.normal(size=512), rng.normal(size=512)
a /= np.linalg.norm(a)
b2 = 0.6 * a + 0.8 * (b2 - (b2 @ a) * a) / np.linalg.norm(b2 - (b2 @ a) * a)
m = (a + b2) / np.linalg.norm(a + b2)
record("P5_ceiling", {
    "printed_real_photo_ceiling": {k: rc[k] for k in ("clip_prompt_similarity", "label_accuracy", "reference_similarity")},
    "note_in_json_only": rc.get("note"),
    "frozen_generations": {k: rep["frozen"]["generations"][k] for k in ("clip_prompt_similarity", "label_accuracy", "reference_similarity")},
    "adapted_generations": {k: rep["adapted"]["generations"][k] for k in ("clip_prompt_similarity", "label_accuracy", "reference_similarity")},
    "per_caption": loo, "leave_one_out_real_reference_similarity_mean": loo_mean,
    "identity_check": {"cos_ab": round(float(a @ b2), 4), "cos_a_mean": round(float(a @ m), 4), "sqrt((1+c)/2)": round(math.sqrt((1 + float(a @ b2)) / 2), 4)},
    "generated_clip_prompt_similarity_exceeds_ceiling": rep["frozen"]["generations"]["clip_prompt_similarity"] > rc["clip_prompt_similarity"],
    "notebook_ceiling_wording": [s for s in ["the ceiling these numbers could reach", "the real-photo ceiling", "the ceiling"] if s in md_all],
})

# ---------------- P6 rerun/state hazards (source)
pipe_src = src[5]
record("P6_rerun_state", {
    "load_transformer_returns_early_if_resident": "if self.transformer is not None:\n            return {\"loaded\": False" in pipe_src,
    "adapt_does_not_reset_lora_before_training": "initial_state = {k: v.detach().clone()" in pipe_src and "frozen model (LoRA at initialisation: B = 0)" in pipe_src,
    "section6_calls_load_transformer": "load_report = pipe.load_transformer()" in src[17],
    "optional_experiments_name_rerun_scope": any(w in src[24] for w in ["re-run from", "rerun from", "Restart", "re-run Section"]),
    "section9_creates_second_pipeline_named_reloaded": "reloaded = FluxSchnellPipeline.from_artifact" in src[23],
    "section5_releases_only_pipe_transformer": "if pipe.transformer is not None:" in src[15] and "reloaded" not in src[15],
    "byod_instruction_rerun_from_section4": "re-run from that cell" in src[0],
})

# ---------------- P7 GPU memory arithmetic for the documented BYOD rerun (Kaggle T4 record of this blob)
exe = json.loads((EV / "executed.ipynb").read_text(encoding="utf-8"))
def cell_text(i):
    return "".join("".join(o.get("text", "")) for o in exe["cells"][i].get("outputs", []))
c15, c23 = cell_text(15), cell_text(23)
import re  # noqa: E402
enc = float(re.search(r"'gpu_memory_gb_with_encoders': ([0-9.]+)", c15).group(1))
base = float(re.search(r"'gpu_memory_gb_after_release': ([0-9.]+)", c15).group(1))
after_reload = float(re.search(r"'reload_parity'.*'gpu_memory_gb': ([0-9.]+)", c23).group(1))
record("P7_byod_rerun_memory", {
    "encoders_resident_gb": enc, "baseline_after_encoder_release_gb": base, "gpu_after_section9_reload_gb": after_reload,
    "projected_peak_gb_if_encoders_load_beside_reloaded": round(after_reload + (enc - base), 2),
    "t4_capacity_gb": round(15360 * 1024 * 1024 / 1e9, 2),
    "note": "projection from the recorded run; not executed (no GPU)",
})

results["wall_seconds"] = round(time.time() - t_start, 1)
results["environment"] = {"python": sys.version.split()[0], "numpy": np.__version__, "pillow": Image.__version__, "device": "CPU (Windows workstation)"}
os.chdir(HERE)
(HERE / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")

manifest = {}
for rel in ["tutorials/flux_schnell_generation_colab.ipynb", "src/flux_schnell_generation_pipeline/pipeline.py",
            "src/flux_schnell_generation_pipeline/samples.py", "src/flux_schnell_generation_pipeline/metrics.py",
            "tools/build_notebook.py", "tools/notebook_template.py", "tutorials/README.md", "README.md", "STATUS.md",
            "docs/release-verification.md"]:
    manifest[rel] = hashlib.sha256((WT / rel).read_bytes()).hexdigest()
for rel in ["executed.ipynb", "run_summary.json", "outputs/flux_schnell_generation_evaluation_report.json"]:
    manifest["kaggle-evidence-v2/" + rel] = hashlib.sha256((EV / rel).read_bytes()).hexdigest()
(HERE / "source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
import shutil  # noqa: E402
shutil.rmtree(work, ignore_errors=True)
print("done", results["wall_seconds"])
